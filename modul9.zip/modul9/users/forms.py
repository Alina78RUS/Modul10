from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm, AuthenticationForm
from django.forms import ModelForm

from users.models import ProfileUser


class ProfileCreationForm(UserCreationForm):
    class Meta:
        model = ProfileUser
        fields = ('username', 'email', 'name', 'surname', 'date_of_birth', 'gender')

class ProfileChangeForm(UserChangeForm):
    class Meta:
        model = ProfileUser
        fields = ('username', 'email', 'name', 'surname', 'date_of_birth', 'gender')


class LoginUserForm(AuthenticationForm):
    username = forms.CharField(label='Логин', widget=forms.TextInput(attrs={'class': 'form-input'}))
    password = forms.CharField(label='Пароль', widget=forms.PasswordInput(attrs={'class': 'form-input'}))

