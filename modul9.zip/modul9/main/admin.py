from django.contrib import admin
from .models import Human, Company, House


admin.site.register(Human)
admin.site.register(Company)
admin.site.register(House)

